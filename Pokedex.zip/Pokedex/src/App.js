import Home from "./component/main/home/home.component";

function App() {
  return (
    <div>
      <Home />
    </div>
  );
}

export default App;
